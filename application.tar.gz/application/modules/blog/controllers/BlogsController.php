<?php
/**
 * Blog Controller
 *
 * @category        Controller
 * @package         Blog
 * @author          Md. Sirajus Salayhin <salayhin@gmail.com>
 * @copyright       Copyright (c) 2011
 */
class Blog_BlogsController extends Speed_Controller_CrudController
{


}

