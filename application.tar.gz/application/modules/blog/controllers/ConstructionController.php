<?php
/**
 * Construction Controller
 *
 * Construction   Controller
 * @package     Discussion
 * @author      Mustafa Ahmed Khan <tamal_29@yahoo.com>
 */
class Blog_ConstructionController extends Speed_Controller_ActionController
{

    public function indexAction()
    {
        $this->disableLayout();


    }

}
