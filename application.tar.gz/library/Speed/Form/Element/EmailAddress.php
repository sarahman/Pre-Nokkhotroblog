<?php

/**
 * Email Address Element
 *
 * @category        Form Element
 * @package         Speed
 * @copyright       Copyright (c) 2011 Right Brain Solution Ltd. http://rightbrainsolution.com
 * @author          Syed Abidur Rahman <abid@rightbrainsolution.com>
 */
class Speed_Form_Element_EmailAddress extends Zend_Form_Element_Text
{
}
